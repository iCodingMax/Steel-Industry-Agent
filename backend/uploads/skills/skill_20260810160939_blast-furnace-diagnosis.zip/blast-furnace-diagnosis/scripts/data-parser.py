#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json
import sys
import pymysql
import os
from datetime import datetime
from decimal import Decimal
from typing import Dict, Any

class DataParser:
    def __init__(self):
        self.raw_data = {}
        self.parsed_data = {}
        self.warnings = []

    # ===================== 你的 MySQL 配置 =====================
    def parse_from_mysql(self, furnace_no="1号高炉", diagnose_time=None):
        conn = pymysql.connect(
            host="localhost",
            port=3306,
            user="admin",
            password="123456",
            database="blast_furnace",
            charset="utf8mb4"
        )
        cursor = conn.cursor(pymysql.cursors.DictCursor)

        if not diagnose_time:
            sql = """SELECT * FROM bf_diagnosis_data WHERE furnace_no=%s ORDER BY diagnose_time DESC LIMIT 1"""
            cursor.execute(sql, (furnace_no,))
        else:
            sql = """SELECT * FROM bf_diagnosis_data WHERE furnace_no=%s AND diagnose_time=%s"""
            cursor.execute(sql, (furnace_no, diagnose_time))

        row = cursor.fetchone()
        conn.close()
        if not row:
            raise Exception("MySQL中未找到数据")

        # 修复：Decimal 转 float
        for k, v in row.items():
            if isinstance(v, Decimal):
                row[k] = float(v)

        self.raw_data = row
        self.parsed_data = self._normalize_data(row)
        return self.parsed_data

    def _normalize_data(self, row: Dict[str, Any]) -> Dict[str, Any]:
        normalized = {
            "_说明": "从MySQL读取并标准化的高炉诊断数据",
            "_版本": "1.0",
            "高炉基本信息": {
                "高炉编号": row["furnace_no"],
                "容积_m3": row["volume_m3"],
                "风口数量": row["tuyere_count"],
                "设计日产量_t": row["design_output_t"],
                "铁口数量": row["taphole_count"]
            },
            "诊断时间": row["diagnose_time"].strftime("%Y-%m-%d %H:%M"),
            "送风参数": {
                "风量_m3_min": row["wind_volume_m3_min"],
                "风压_kPa": row["wind_pressure_kpa"],
                "风温_℃": row["wind_temp_c"],
                "顶压_kPa": row["top_pressure_kpa"],
                "富氧率_%": row["oxygen_enrich_pct"],
                "湿度_g_m3": row["humidity_g_m3"],
                "透气性指数_K": row["permeability_k"]
            },
            "炉缸热状态": {
                "铁水温度_℃": row["hot_metal_temp_c"],
                "铁水Si_%": row["si_pct"],
                "铁水S_%": row["s_pct"],
                "铁水Mn_%": row["mn_pct"],
                "铁水Ti_%": row["ti_pct"],
                "铁水P_%": row["p_pct"]
            },
            "炉料运动": {
                "当前料批时间_min": row["batch_time_min"],
                "正常料批时间_min": row["normal_batch_time_min"],
                "料线深度_m": row["stock_line_m"],
                "料线目标_m": row["stock_line_target_m"],
                "是否有料线异常": bool(row["stock_line_abnormal"]),
                "料速描述": row["stock_speed_desc"]
            },
            "煤气成分": {
                "炉顶CO2_%": row["co2_pct"],
                "炉顶CO_%": row["co_pct"],
                "炉顶H2_%": row["h2_pct"],
                "煤气利用率_%": row["gas_usage_pct"]
            },
            "装料参数": {
                "焦炭负荷_O_C": row["coke_load"],
                "喷煤量_kg_tHM": row["coal_injection_kg"],
                "焦比_kg_tHM": row["coke_rate"],
                "燃料比_kg_tHM": row["fuel_rate"],
                "日产量_t": row["daily_output_t"],
                "利用系数_t_m3_d": row["utilization_coeff"]
            },
            "炉渣参数": {
                "炉渣碱度_R2": row["slag_basicity"],
                "炉渣MgO_%": row["slag_mgo_pct"],
                "炉渣Al2O3_%": row["slag_al2o3_pct"]
            },
            "风口信息": {
                "总风口数": row["tuyere_count"],
                "堵口数量": row["tuyere_blocked"],
                "异常风口": [],
                "风口观察描述": row["tuyere_desc"]
            },
            "操作员备注": row["operator_note"]
        }
        self._calculate_derived_params(normalized)
        return normalized

    def _calculate_derived_params(self, data):
        wind = data.get("送风参数", {})
        try:
            if not wind.get("透气性指数_K"):
                wind["透气性指数_K"] = round(wind["风量_m3_min"] / (wind["风压_kPa"] - wind["顶压_kPa"]), 2)
        except: pass

        gas = data.get("煤气成分", {})
        try:
            if not gas.get("煤气利用率_%"):
                gas["煤气利用率_%"] = round(gas["炉顶CO2_%"] / (gas["炉顶CO2_%"] + gas["炉顶CO_%"]) * 100, 2)
        except: pass

def main():
    parser = DataParser()
    try:
        data = parser.parse_from_mysql()
        data["_解析信息"] = {
            "来源": "MySQL",
            "解析时间": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        # ===================== 核心修改：输出到 assets/diagnosis_output_时间戳.json =====================
        # 获取当前脚本所在目录的上级目录（blast-furnace-project）
        project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        output_dir = os.path.join(project_root, "assets")

        # 确保 assets 目录存在
        os.makedirs(output_dir, exist_ok=True)

        # 生成带时间戳的文件名
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_filename = f"diagnosis_output_{timestamp}.json"

        # 定义输出文件路径
        output_file = os.path.join(output_dir, output_filename)

        # 同时更新一个固定的最新文件链接（便于脚本读取）
        latest_link = os.path.join(output_dir, "diagnosis_output_latest.json")

        # 修复：安全 JSON 序列化
        def json_default(obj):
            if isinstance(obj, Decimal):
                return float(obj)
            raise TypeError

        output_json = json.dumps(data, ensure_ascii=False, indent=2, default=json_default)

        # 写入文件
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(output_json)

        # 创建/更新最新文件链接（复制文件内容）
        with open(latest_link, "w", encoding="utf-8") as f:
            f.write(output_json)

        print(f"[成功] 输出成功！文件路径：\n{output_file}")
        print(f"[成功] 最新文件链接：{latest_link}")

    except Exception as e:
        print(f"[错误]：{e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()