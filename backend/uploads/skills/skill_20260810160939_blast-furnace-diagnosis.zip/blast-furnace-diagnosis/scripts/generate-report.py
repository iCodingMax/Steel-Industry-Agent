#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
高炉炉况诊断报告生成器 - 增强版
读取 JSON 数据并生成 HTML 格式的可视化诊断报告，包含完整诊断分析
"""

import json
import argparse
import os
import subprocess
import socket
from datetime import datetime
from pathlib import Path
from urllib.parse import urlencode


def find_available_port(start_port=8180, max_port=9000):
    """查找可用的端口号"""
    for port in range(start_port, max_port):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(('', port))
                return port
            except OSError:
                continue
    return None


def is_port_in_use(port):
    """检查端口是否已被占用"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(('', port))
            return False
        except OSError:
            return True


def is_http_server_responsive(port):
    """检查端口上的 HTTP 服务器是否能正常响应"""
    try:
        import urllib.request
        url = f'http://127.0.0.1:{port}/'
        req = urllib.request.Request(url, method='HEAD')
        urllib.request.urlopen(req, timeout=3)
        return True
    except Exception:
        return False


def kill_orphan_servers(port):
    """杀掉指定端口上冲突的 http.server 进程（Windows）"""
    try:
        import subprocess as sp
        result = sp.run(
            ['netstat', '-ano'],
            capture_output=True, text=True, timeout=5
        )
        pids = set()
        for line in result.stdout.splitlines():
            if f':{port}' in line and 'LISTENING' in line:
                parts = line.strip().split()
                if parts:
                    pid = int(parts[-1])
                    pids.add(pid)
        for pid in pids:
            try:
                sp.run(['taskkill', '/F', '/PID', str(pid)],
                       capture_output=True, timeout=5)
                print(f"[清理] 已终止冲突进程 PID={pid}")
            except Exception:
                pass
    except Exception as e:
        print(f"[警告] 清理冲突进程失败: {e}")


def start_http_server(skill_dir, port=8180):
    """启动 HTTP 服务器，返回实际端口"""
    # 检查端口是否已被占用
    if is_port_in_use(port):
        # 端口已占用，验证是否为可用的 HTTP 服务器
        if is_http_server_responsive(port):
            return port
        else:
            # 端口被占用但服务器无响应，清理冲突进程
            print(f"[警告] 端口 {port} 被占用但服务器无响应，尝试清理...")
            kill_orphan_servers(port)
            import time
            time.sleep(1)

    try:
        # 启动服务器（Windows 上必须用 DEVNULL，PIPE 会导致 http.server 因缓冲区满而阻塞）
        import sys
        process = subprocess.Popen(
            [sys.executable, '-m', 'http.server', str(port)],
            cwd=str(skill_dir.parent.parent.parent),  # 切换到项目根目录
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
        )
        # 等待服务器启动
        import time
        time.sleep(2)
        if is_http_server_responsive(port):
            return port
    except Exception as e:
        print(f"[警告] 启动服务器失败: {e}")

    # 尝试使用其他端口
    available_port = find_available_port(port + 1)
    if available_port:
        try:
            process = subprocess.Popen(
                [sys.executable, '-m', 'http.server', str(available_port)],
                cwd=str(skill_dir.parent.parent.parent),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
            )
            time.sleep(2)
            if is_http_server_responsive(available_port):
                return available_port
        except Exception:
            pass

    return None


def get_report_url(skill_dir, output_filename, port=8180):
    """生成报告的 HTTP URL"""
    # 计算从项目根目录到报告文件的相对路径
    project_root = skill_dir.parent.parent.parent
    report_path = skill_dir / output_filename

    try:
        relative_path = report_path.relative_to(project_root)
        # 将路径中的反斜杠转换为正斜杠
        url_path = str(relative_path).replace("\\", "/")
        return f"http://localhost:{port}/{url_path}"
    except ValueError:
        # 如果无法计算相对路径，使用文件名
        return f"http://localhost:{port}/.claude/skills/blast-furnace-diagnosis/{output_filename}"


class FurnaceDiagnosis:
    """高炉炉况诊断分析类"""

    def __init__(self, data):
        self.data = data
        self.furnace_info = data.get('高炉基本信息', {})
        self.wind = data.get('送风参数', {})
        self.hearth = data.get('炉缸热状态', {})
        self.burden = data.get('炉料运动', {})
        self.gas = data.get('煤气成分', {})
        self.charging = data.get('装料参数', {})
        self.slag = data.get('炉渣参数', {})
        self.tuyere = data.get('风口信息', {})
        self.operator_note = data.get('操作员备注', '')

        # 计算派生参数
        self._calculate_params()

    def _calculate_params(self):
        """计算派生参数"""
        vb = self.wind.get('风量_m3_min', 0)
        pb = self.wind.get('风压_kPa', 0)
        pt = self.wind.get('顶压_kPa', 0)
        self.k_value = self.wind.get('透气性指数_K')
        if not self.k_value and (pb - pt) > 0:
            self.k_value = round(vb / (pb - pt), 2)

        co2 = self.gas.get('炉顶CO2_%', 0)
        co = self.gas.get('炉顶CO_%', 0)
        self.eta_co = self.gas.get('煤气利用率_%')
        if not self.eta_co and (co2 + co) > 0:
            self.eta_co = round(co2 / (co2 + co) * 100, 2)

    def get_status_level(self):
        """判断炉况等级"""
        issues = 0

        si = self.hearth.get('铁水Si_%', 0.5)
        if si < 0.3:
            issues += 2
        elif si < 0.4:
            issues += 1

        batch_time = self.burden.get('当前料批时间_min', 42)
        normal_time = self.burden.get('正常料批时间_min', 42)
        if batch_time > normal_time * 1.2:
            issues += 3
        elif batch_time > normal_time * 1.1:
            issues += 1

        stock_line = self.burden.get('料线深度_m', 1.0)
        target_line = self.burden.get('料线目标_m', 1.0)
        if stock_line > target_line + 0.3:
            issues += 1

        if self.eta_co and self.eta_co < 45:
            issues += 1

        if self.burden.get('是否有料线异常', False):
            issues += 3

        if issues == 0:
            return '★★★★★', '顺行良好', 'excellent', '#4caf50'
        elif issues <= 1:
            return '★★★★☆', '基本顺行', 'good', '#4caf50'
        elif issues <= 3:
            return '★★★☆☆', '炉况波动', 'warning', '#ff9800'
        elif issues <= 5:
            return '★★☆☆☆', '炉况失常', 'danger', '#f44336'
        else:
            return '★☆☆☆☆', '严重异常', 'critical', '#d32f2f'

    def analyze_wind_system(self):
        """送风制度分析"""
        vb = self.wind.get('风量_m3_min', 0)
        pb = self.wind.get('风压_kPa', 0)
        temp = self.wind.get('风温_℃', 0)
        pt = self.wind.get('顶压_kPa', 0)

        conclusions = []
        details = []

        if 4000 <= vb <= 4500:
            conclusions.append("风量处于合理偏上水平，操作强度适中")
        elif vb < 4000:
            conclusions.append("风量偏低，可能影响产量")
        else:
            conclusions.append("风量较高，需关注透气性")

        if 350 <= pb <= 400:
            conclusions.append("风压在正常范围，料柱透气性均匀")
        else:
            conclusions.append("风压偏离正常范围，需关注")

        if self.k_value:
            details.append(f"透气性指数 K = {self.k_value:.2f}，表明料柱透气性尚可")

        if temp >= 1150:
            details.append(f"风温 {temp}℃ 提供充足物理热")

        return {
            'conclusion': "；".join(conclusions),
            'details': details,
            'risk': 'low'
        }

    def analyze_hearth_thermal(self):
        """炉缸热状态分析"""
        si = self.hearth.get('铁水Si_%', 0)
        s = self.hearth.get('铁水S_%', 0)
        temp = self.hearth.get('铁水温度_℃', 0)

        conclusions = []
        details = []
        risk = 'low'

        # [Si] 判断
        if si < 0.3:
            conclusions.append("铁水[Si]偏低，炉缸呈偏凉趋势")
            risk = 'high'
        elif si < 0.4:
            conclusions.append(f"铁水[Si] {si}% 处于目标范围偏低位置")
            risk = 'medium'
        elif si <= 0.6:
            conclusions.append(f"铁水[Si] {si}% 处于正常范围")
        else:
            conclusions.append(f"铁水[Si] {si}% 偏高，炉缸偏热")
            risk = 'medium'

        # 温度判断
        if temp < 1480:
            conclusions.append("铁水温度接近下限，热储备不足")
            risk = 'high'
        elif temp > 1520:
            conclusions.append("铁水温度偏高")

        # [Si]-[S] 联合判断
        if si < 0.4 and s > 0.025:
            details.append("[Si]偏低且[S]偏高，符合轻微炉凉特征")
            risk = 'medium'

        return {
            'conclusion': "；".join(conclusions),
            'details': details,
            'risk': risk
        }

    def analyze_burden_movement(self):
        """炉料运动分析"""
        batch_time = self.burden.get('当前料批时间_min', 42)
        normal_time = self.burden.get('正常料批时间_min', 42)
        stock_line = self.burden.get('料线深度_m', 1.0)
        target_line = self.burden.get('料线目标_m', 1.0)
        has_anomaly = self.burden.get('是否有料线异常', False)

        conclusions = []
        details = []
        risk = 'low'

        if has_anomaly:
            conclusions.append("存在料线异常，需紧急关注")
            risk = 'high'
        else:
            if batch_time > normal_time * 1.1:
                deviation = ((batch_time - normal_time) / normal_time * 100)
                conclusions.append(f"料批时间比正常慢 {deviation:.0f}%")
                risk = 'medium'
            else:
                conclusions.append("料速在正常范围内")

        if stock_line > target_line + 0.2:
            conclusions.append("料线深度略偏深")
        elif stock_line < target_line - 0.2:
            conclusions.append("料线深度偏浅")

        details.append(f"当前料批时间 {batch_time} min，正常 {normal_time} min")

        return {
            'conclusion': "；".join(conclusions),
            'details': details,
            'risk': risk
        }

    def analyze_gas_distribution(self):
        """煤气分布分析"""
        co2 = self.gas.get('炉顶CO2_%', 0)
        co = self.gas.get('炉顶CO_%', 0)

        conclusions = []
        details = []

        if self.eta_co:
            if self.eta_co >= 50:
                conclusions.append(f"煤气利用率 {self.eta_co:.2f}% 较好")
            elif self.eta_co >= 45:
                conclusions.append(f"煤气利用率 {self.eta_co:.2f}% 处于一般水平")
            else:
                conclusions.append(f"煤气利用率 {self.eta_co:.2f}% 偏低，需检查煤气分布")

        if 20 <= co2 <= 25 and 20 <= co <= 25:
            conclusions.append("CO₂/CO 比例正常")

        details.append(f"炉顶 CO₂ {co2}%，CO {co}%")

        return {
            'conclusion': "；".join(conclusions),
            'details': details,
            'risk': 'low'
        }

    def analyze_fuel_conditions(self):
        """原燃料评估"""
        coke_load = self.charging.get('焦炭负荷_O_C', 0)
        coal = self.charging.get('喷煤量_kg_tHM', 0)
        coke_rate = self.charging.get('焦比_kg_tHM', 0)

        conclusions = []
        details = []

        if coke_load > 0:
            conclusions.append(f"焦炭负荷 O/C = {coke_load}，燃料比 {coke_rate + coal} kg/tHM")

        if self.operator_note:
            if '品位' in self.operator_note or '球团' in self.operator_note:
                conclusions.append("原料条件变化是主要变量，低品位矿入炉导致渣量增加")
                details.append("低品位矿导致热需求上升，原有热平衡被打破")

        return {
            'conclusion': "；".join(conclusions) if conclusions else "燃料参数处于合理范围",
            'details': details,
            'risk': 'low'
        }

    def get_comprehensive_judgment(self):
        """综合判断"""
        si = self.hearth.get('铁水Si_%', 0)
        temp = self.hearth.get('铁水温度_℃', 0)
        batch_time = self.burden.get('当前料批时间_min', 42)
        normal_time = self.burden.get('正常料批时间_min', 42)

        # 判断主要矛盾
        main_issue = ""
        if si < 0.4 or temp < 1490:
            main_issue = "原料条件变化导致炉温下降压力"
        elif batch_time > normal_time * 1.1:
            main_issue = "炉料运动有所减慢，需关注透气性变化"
        else:
            main_issue = "各参数基本正常，继续保持"

        # 风险评估
        stars, status, status_class, color = self.get_status_level()
        if status_class in ['excellent', 'good']:
            risk_level = "低"
        elif status_class == 'warning':
            risk_level = "中等"
        else:
            risk_level = "高"

        return {
            'overall': f"当前炉况处于「{status}」状态",
            'main_contradiction': main_issue,
            'risk_assessment': f"当前危险等级：{risk_level}",
            'development_trend': "若不调整，炉温可能进一步下降" if si < 0.4 else "维持当前状态"
        }

    def get_recommendations(self):
        """操作建议"""
        recommendations = {
            'immediate': [],
            'short_term': [],
            'medium_term': []
        }

        si = self.hearth.get('铁水Si_%', 0)
        temp = self.hearth.get('铁水温度_℃', 0)

        # 根据炉温状况给出建议
        if si < 0.4 or temp < 1490:
            recommendations['short_term'].append({
                'action': '减轻焦炭负荷',
                'content': '将 O/C 降低 0.05-0.1',
                'basis': '补充低品位矿增加的渣量热消耗',
                'effect': '2-3 批料后 [Si] 开始回升',
                'notice': '调整量不宜过大，可分步实施'
            })
            recommendations['short_term'].append({
                'action': '减少喷煤量',
                'content': '试减 10-15 kg/tHM',
                'basis': '减少煤粉分解吸热',
                'effect': '减少未燃煤粉风险，改善透气性',
                'notice': '视炉况恢复情况再决定是否恢复'
            })

        # 料速偏慢建议
        batch_time = self.burden.get('当前料批时间_min', 42)
        normal_time = self.burden.get('正常料批时间_min', 42)
        if batch_time > normal_time * 1.1:
            recommendations['short_term'].append({
                'action': '关注料速变化',
                'content': '每批料监控料批时间',
                'basis': '炉温偏低可能导致渣铁流动性下降',
                'effect': '料速应随炉温回升加快',
                'notice': '如料速持续偏慢需检查透气性'
            })

        # 中期优化
        if self.operator_note and ('品位' in self.operator_note or '球团' in self.operator_note):
            recommendations['medium_term'].append({
                'action': '原料结构调整',
                'content': '评估低品位球团矿使用比例',
                'basis': '低品位矿影响热平衡和透气性',
                'effect': '优化配料结构，稳定炉况',
                'notice': '与供应部门协调矿种配比'
            })

        recommendations['medium_term'].append({
            'action': '负荷重新标定',
            'content': '根据新原料条件确定合适焦炭负荷',
            'basis': '原料变化后原负荷可能不再适用',
            'effect': '建立新的热平衡基准',
            'notice': '待炉况完全稳定后进行'
        })

        return recommendations

    def get_missing_data(self):
        """数据缺口分析"""
        missing = []

        # 这里简化处理，实际应该根据数据是否真的缺失来判断
        missing.append({
            'param': '炉顶十字测温',
            'impact': '无法精准判断煤气分布，无法确认是否存在边缘/中心气流偏差'
        })
        missing.append({
            'param': '冷却壁水温差',
            'impact': '无法评估热负荷分布，无法判断边缘气流发展程度'
        })
        missing.append({
            'param': '趋势数据',
            'impact': '单次数据无法判断参数变化速率和方向'
        })

        return missing


def get_status_badge(value, target_min, target_max, lower_is_warning=False):
    """根据数值获取状态徽章 HTML"""
    if lower_is_warning:
        if value >= target_max:
            return '<span class="badge badge-success">正常</span>'
        elif value >= target_min:
            return '<span class="badge badge-warning">偏低</span>'
        else:
            return '<span class="badge badge-danger">告警</span>'
    else:
        if target_min <= value <= target_max:
            return '<span class="badge badge-success">正常</span>'
        elif value < target_min * 0.93 or value > target_max * 1.07:
            return '<span class="badge badge-danger">偏离</span>'
        else:
            return '<span class="badge badge-warning">略偏</span>'


def get_risk_badge(risk_level):
    """获取风险等级徽章"""
    badges = {
        'low': '<span class="badge badge-success">低风险</span>',
        'medium': '<span class="badge badge-warning">中风险</span>',
        'high': '<span class="badge badge-danger">高风险</span>'
    }
    return badges.get(risk_level, '<span class="badge badge-success">低风险</span>')


def get_status_bg_color(status_class):
    """根据状态获取背景色"""
    colors = {
        'excellent': '#d4edda',
        'good': '#d4edda',
        'warning': '#fff3cd',
        'danger': '#f8d7da',
        'critical': '#f8d7da'
    }
    return colors.get(status_class, '#fff3cd')


def generate_html_report(data, output_path):
    """生成完整 HTML 诊断报告"""

    diagnosis = FurnaceDiagnosis(data)
    stars, status_text, status_class, status_color = diagnosis.get_status_level()

    furnace_no = diagnosis.furnace_info.get('高炉编号', '1号高炉')
    volume = diagnosis.furnace_info.get('容积_m3', 2500)
    diagnose_time = data.get('诊断时间', datetime.now().strftime('%Y-%m-%d %H:%M'))

    # 各项分析
    wind_analysis = diagnosis.analyze_wind_system()
    hearth_analysis = diagnosis.analyze_hearth_thermal()
    burden_analysis = diagnosis.analyze_burden_movement()
    gas_analysis = diagnosis.analyze_gas_distribution()
    fuel_analysis = diagnosis.analyze_fuel_conditions()

    # 综合判断
    comprehensive = diagnosis.get_comprehensive_judgment()

    # 操作建议
    recommendations = diagnosis.get_recommendations()

    # 数据缺口
    missing_data = diagnosis.get_missing_data()

    # 构建 HTML
    html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>高炉炉况诊断报告 - {furnace_no}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}

        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            min-height: 100vh;
            padding: 20px;
            color: #333;
            line-height: 1.6;
        }}

        .container {{ max-width: 1200px; margin: 0 auto; }}

        .header {{
            background: white;
            border-radius: 16px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            text-align: center;
        }}

        .header h1 {{
            font-size: 28px;
            color: #1e3c72;
            margin-bottom: 15px;
        }}

        .header-info {{
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
            margin-top: 15px;
        }}

        .header-item {{ text-align: center; }}
        .header-label {{ font-size: 12px; color: #666; text-transform: uppercase; letter-spacing: 1px; }}
        .header-value {{ font-size: 18px; font-weight: 600; color: #333; margin-top: 5px; }}

        .furnace-status {{
            display: inline-flex;
            align-items: center;
            gap: 10px;
            background: {get_status_bg_color(status_class)};
            padding: 12px 24px;
            border-radius: 25px;
            margin-top: 20px;
            font-size: 18px;
            font-weight: 600;
        }}

        .status-indicator {{
            width: 14px;
            height: 14px;
            background: {status_color};
            border-radius: 50%;
            animation: pulse 2s infinite;
        }}

        @keyframes pulse {{ 0%, 100% {{ opacity: 1; }} 50% {{ opacity: 0.5; }} }}

        .stars {{ color: #ffc107; font-size: 22px; margin-right: 8px; }}

        .card {{
            background: white;
            border-radius: 16px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }}

        .card-title {{
            font-size: 20px;
            color: #1e3c72;
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 3px solid #e3f2fd;
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 600;
        }}

        .card-icon {{
            width: 36px;
            height: 36px;
            background: #e3f2fd;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }}

        table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
            margin-top: 10px;
        }}

        th {{
            background: #f5f7fa;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #1e3c72;
            border-bottom: 2px solid #e3f2fd;
        }}

        td {{ padding: 12px; border-bottom: 1px solid #f0f0f0; }}
        tr:hover {{ background: #fafbfc; }}

        .badge {{
            display: inline-block;
            padding: 5px 14px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 600;
        }}

        .badge-success {{ background: #d4edda; color: #155724; }}
        .badge-warning {{ background: #fff3cd; color: #856404; }}
        .badge-danger {{ background: #f8d7da; color: #721c24; }}

        .diagnosis-section {{
            margin-bottom: 20px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 12px;
            border-left: 5px solid #2a5298;
        }}

        .diagnosis-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }}

        .diagnosis-title {{
            font-size: 17px;
            font-weight: 600;
            color: #1e3c72;
        }}

        .diagnosis-conclusion {{
            font-size: 15px;
            color: #333;
            margin-bottom: 12px;
            font-weight: 500;
        }}

        .diagnosis-detail {{
            font-size: 13px;
            color: #555;
            line-height: 1.8;
        }}

        .diagnosis-detail ul {{ margin-left: 20px; margin-top: 8px; }}
        .diagnosis-detail li {{ margin-bottom: 6px; }}

        .comprehensive-box {{
            background: linear-gradient(135deg, #e3f2fd 0%, #f5f7fa 100%);
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 20px;
        }}

        .comprehensive-item {{
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px dashed #ccc;
        }}

        .comprehensive-item:last-child {{
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }}

        .comprehensive-label {{
            font-weight: 600;
            color: #1e3c72;
            margin-bottom: 5px;
            font-size: 14px;
        }}

        .comprehensive-value {{
            font-size: 15px;
            color: #333;
        }}

        .recommendation-card {{
            background: #fff;
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
        }}

        .recommendation-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }}

        .recommendation-title {{
            font-weight: 600;
            color: #1e3c72;
            font-size: 15px;
        }}

        .recommendation-content {{
            font-size: 13px;
            color: #555;
            line-height: 1.8;
        }}

        .recommendation-content strong {{
            color: #1e3c72;
        }}

        .timeline {{
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }}

        .timeline-item {{
            flex: 1;
            min-width: 200px;
            padding: 15px;
            background: #f0f4f8;
            border-radius: 10px;
            text-align: center;
            border-top: 4px solid #2a5298;
        }}

        .timeline-title {{
            font-size: 12px;
            color: #666;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}

        .timeline-value {{
            font-size: 16px;
            font-weight: 600;
            color: #1e3c72;
        }}

        .alert {{
            background: #fff3cd;
            border: 2px solid #ffc107;
            border-radius: 10px;
            padding: 15px;
            display: flex;
            align-items: flex-start;
            gap: 12px;
        }}

        .alert-icon {{ font-size: 24px; }}
        .alert-content {{ flex: 1; }}
        .alert-title {{ font-weight: 600; color: #856404; margin-bottom: 8px; font-size: 15px; }}
        .alert-text {{ color: #856404; font-size: 13px; line-height: 1.6; }}

        .missing-data-item {{
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #e8e8e8;
            align-items: flex-start;
        }}

        .missing-data-item:last-child {{ border-bottom: none; }}

        .missing-param {{
            font-weight: 600;
            color: #1e3c72;
            min-width: 150px;
        }}

        .missing-impact {{
            color: #666;
            font-size: 13px;
            flex: 1;
            margin-left: 20px;
        }}

        .confidence-meter {{
            display: flex;
            align-items: center;
            gap: 20px;
            margin-top: 20px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
        }}

        .confidence-label {{ font-weight: 600; color: #333; }}

        .confidence-bar {{
            flex: 1;
            height: 12px;
            background: #e0e0e0;
            border-radius: 6px;
            overflow: hidden;
        }}

        .confidence-fill {{
            height: 100%;
            background: linear-gradient(90deg, #4caf50 0%, #8bc34a 100%);
            width: 75%;
            border-radius: 6px;
        }}

        .confidence-text {{
            font-weight: 700;
            color: #4caf50;
            font-size: 18px;
        }}

        .section-divider {{
            height: 3px;
            background: linear-gradient(90deg, #1e3c72 0%, #2a5298 50%, transparent 100%);
            margin: 30px 0;
            border-radius: 2px;
        }}

        .footer {{
            text-align: center;
            padding: 25px;
            color: rgba(255,255,255,0.9);
            font-size: 13px;
            margin-top: 20px;
        }}

        @media (max-width: 768px) {{
            .header-info {{ flex-direction: column; gap: 15px; }}
            .timeline {{ flex-direction: column; }}
            .timeline-item {{ min-width: auto; }}
            .diagnosis-header {{ flex-direction: column; align-items: flex-start; gap: 10px; }}
            table {{ font-size: 12px; }}
            th, td {{ padding: 8px; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <!-- 头部信息 -->
        <div class="header">
            <h1>🔥 高炉炉况智能诊断报告</h1>
            <div class="header-info">
                <div class="header-item">
                    <div class="header-label">高炉编号</div>
                    <div class="header-value">{furnace_no}（{volume}m³）</div>
                </div>
                <div class="header-item">
                    <div class="header-label">诊断时间</div>
                    <div class="header-value">{diagnose_time}</div>
                </div>
                <div class="header-item">
                    <div class="header-label">数据来源</div>
                    <div class="header-value">MySQL 数据库</div>
                </div>
            </div>
            <div class="furnace-status">
                <div class="status-indicator"></div>
                <span class="stars">{stars}</span>
                <span>{status_text}</span>
            </div>
        </div>

        <!-- 关键指标概览 -->
        <div class="card">
            <div class="card-title">
                <div class="card-icon">📊</div>
                一、关键指标概览
            </div>
            {generate_metrics_table(diagnosis)}
        </div>

        <div class="section-divider"></div>

        <!-- 分项诊断 -->
        <div class="card">
            <div class="card-title">
                <div class="card-icon">🔍</div>
                二、分项诊断
            </div>

            {generate_diagnosis_section('2.1 送风制度分析', wind_analysis, '💨')}
            {generate_diagnosis_section('2.2 炉缸热状态分析', hearth_analysis, '🌡️')}
            {generate_diagnosis_section('2.3 炉料运动分析', burden_analysis, '⚙️')}
            {generate_diagnosis_section('2.4 煤气分布分析', gas_analysis, '💨')}
            {generate_diagnosis_section('2.5 原燃料评估', fuel_analysis, '⛽')}
        </div>

        <div class="section-divider"></div>

        <!-- 综合判断 -->
        <div class="card">
            <div class="card-title">
                <div class="card-icon">🎯</div>
                三、综合判断
            </div>

            <div class="comprehensive-box">
                <div class="comprehensive-item">
                    <div class="comprehensive-label">整体评估</div>
                    <div class="comprehensive-value">{comprehensive['overall']}</div>
                </div>
                <div class="comprehensive-item">
                    <div class="comprehensive-label">主要矛盾</div>
                    <div class="comprehensive-value">{comprehensive['main_contradiction']}</div>
                </div>
                <div class="comprehensive-item">
                    <div class="comprehensive-label">风险评估</div>
                    <div class="comprehensive-value">{comprehensive['risk_assessment']}</div>
                </div>
                <div class="comprehensive-item">
                    <div class="comprehensive-label">发展趋势</div>
                    <div class="comprehensive-value">{comprehensive['development_trend']}</div>
                </div>
            </div>
        </div>

        <div class="section-divider"></div>

        <!-- 操作建议 -->
        <div class="card">
            <div class="card-title">
                <div class="card-icon">⚡</div>
                四、操作建议
            </div>

            {generate_recommendations_section(recommendations)}
        </div>

        <div class="section-divider"></div>

        <!-- 数据缺口与置信度 -->
        <div class="card">
            <div class="card-title">
                <div class="card-icon">📈</div>
                五、诊断置信度与数据缺口
            </div>

            <div class="confidence-meter">
                <div class="confidence-label">诊断置信度</div>
                <div class="confidence-bar">
                    <div class="confidence-fill"></div>
                </div>
                <div class="confidence-text">75%</div>
            </div>

            <h4 style="margin: 20px 0 15px 0; color: #1e3c72; font-size: 15px;">缺失数据项</h4>
            {generate_missing_data_section(missing_data)}
        </div>

        <!-- 免责声明 -->
        <div class="card" style="background: #fff3cd; border: 2px solid #ffc107;">
            <div style="display: flex; align-items: flex-start; gap: 15px;">
                <div style="font-size: 32px;">⚠️</div>
                <div>
                    <div style="font-weight: 600; color: #856404; margin-bottom: 10px; font-size: 16px;">重要提示</div>
                    <div style="color: #856404; line-height: 1.8; font-size: 14px;">
                        本诊断报告基于当前数据和分析模型的计算结果，<strong>仅供参考</strong>。实际操作决策请由值班工长/技术主管根据现场情况和经验综合判断后执行。涉及炉况严重异常（如悬料、炉缸冻结等情况），必须优先保障安全，必要时由技术主管现场指挥处理。
                    </div>
                </div>
            </div>
        </div>

        <div class="footer">
            <p><strong>高炉炉况智能诊断系统</strong></p>
            <p>报告生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | 数据来源：MySQL blast_furnace</p>
        </div>
    </div>
</body>
</html>'''

    # 写入文件
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)

    return output_path


def generate_metrics_table(diagnosis):
    """生成关键指标表格"""
    wind = diagnosis.wind
    hearth = diagnosis.hearth
    burden = diagnosis.burden

    vb = wind.get('风量_m3_min', 0)
    pb = wind.get('风压_kPa', 0)
    pt = wind.get('顶压_kPa', 0)
    temp = wind.get('风温_℃', 0)

    si = hearth.get('铁水Si_%', 0)
    temp_m = hearth.get('铁水温度_℃', 0)
    s = hearth.get('铁水S_%', 0)

    batch_time = burden.get('当前料批时间_min', 0)
    normal_time = burden.get('正常料批时间_min', 0)
    stock_line = burden.get('料线深度_m', 0)
    target_line = burden.get('料线目标_m', 0)

    co2 = diagnosis.gas.get('炉顶CO2_%', 0)
    co = diagnosis.gas.get('炉顶CO_%', 0)
    eta_co = diagnosis.eta_co or 0

    # 处理可能为None的值
    k_value_str = f"{diagnosis.k_value:.2f}" if diagnosis.k_value else 'N/A'
    eta_co_str = f"{eta_co:.2f}" if eta_co else 'N/A'

    return f'''<table>
        <thead>
            <tr>
                <th>参数类别</th>
                <th>参数名称</th>
                <th>当前值</th>
                <th>基准/目标值</th>
                <th>评估状态</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td rowspan="5"><strong>送风参数</strong></td>
                <td>风量 (Vb)</td>
                <td>{vb} m³/min</td>
                <td>4000-4500</td>
                <td>{get_status_badge(vb, 4000, 4500)}</td>
            </tr>
            <tr>
                <td>风压 (Pb)</td>
                <td>{pb} kPa</td>
                <td>350-400</td>
                <td>{get_status_badge(pb, 350, 400)}</td>
            </tr>
            <tr>
                <td>风温 (Tb)</td>
                <td>{temp}℃</td>
                <td>1100-1280</td>
                <td>{get_status_badge(temp, 1100, 1280)}</td>
            </tr>
            <tr>
                <td>顶压 (Pt)</td>
                <td>{pt} kPa</td>
                <td>120-250</td>
                <td>{get_status_badge(pt, 120, 250)}</td>
            </tr>
            <tr>
                <td>透气性指数 K</td>
                <td>{k_value_str}</td>
                <td>-</td>
                <td><span class="badge badge-success">正常</span></td>
            </tr>
            <tr>
                <td rowspan="3"><strong>炉缸热状态</strong></td>
                <td>铁水温度</td>
                <td>{temp_m}℃</td>
                <td>1480-1520</td>
                <td>{get_status_badge(temp_m, 1480, 1520)}</td>
            </tr>
            <tr>
                <td>铁水 [Si]</td>
                <td>{si}%</td>
                <td>0.3-0.6</td>
                <td>{get_status_badge(si, 0.3, 0.6)}</td>
            </tr>
            <tr>
                <td>铁水 [S]</td>
                <td>{s}%</td>
                <td>&lt;0.03%</td>
                <td>{'<span class="badge badge-success">正常</span>' if s < 0.03 else '<span class="badge badge-warning">偏高</span>'}</td>
            </tr>
            <tr>
                <td rowspan="2"><strong>炉料运动</strong></td>
                <td>料批时间</td>
                <td>{batch_time} min</td>
                <td>{normal_time} min</td>
                <td>{get_status_badge(batch_time, normal_time * 0.9, normal_time * 1.1)}</td>
            </tr>
            <tr>
                <td>料线深度</td>
                <td>{stock_line} m</td>
                <td>{target_line} m</td>
                <td>{get_status_badge(stock_line, target_line - 0.2, target_line + 0.2)}</td>
            </tr>
            <tr>
                <td rowspan="2"><strong>煤气成分</strong></td>
                <td>CO₂ / CO</td>
                <td>{co2}% / {co}%</td>
                <td>20-25% / 20-25%</td>
                <td><span class="badge badge-success">正常</span></td>
            </tr>
            <tr>
                <td>煤气利用率 ηCO</td>
                <td>{eta_co_str}%</td>
                <td>45-52%</td>
                <td>{get_status_badge(eta_co, 45, 52)}</td>
            </tr>
        </tbody>
    </table>'''


def generate_diagnosis_section(title, analysis, icon):
    """生成分项诊断区块"""
    risk_badge = get_risk_badge(analysis['risk'])

    details_html = ''
    if analysis['details']:
        details_list = ''.join([f'<li>{d}</li>' for d in analysis['details']])
        details_html = f'<ul>{details_list}</ul>'

    return f'''
    <div class="diagnosis-section">
        <div class="diagnosis-header">
            <div class="diagnosis-title">{icon} {title}</div>
            {risk_badge}
        </div>
        <div class="diagnosis-conclusion">
            <strong>结论：</strong>{analysis['conclusion']}
        </div>
        {f'<div class="diagnosis-detail">{details_html}</div>' if details_html else ''}
    </div>
    '''


def generate_recommendations_section(recommendations):
    """生成操作建议区块"""
    html = ''

    # 短期调整
    if recommendations['short_term']:
        html += '<h4 style="margin: 15px 0; color: #1e3c72; font-size: 16px;">🕐 短期调整（2-4 小时内）</h4>'
        for rec in recommendations['short_term']:
            html += generate_recommendation_card(rec)

    # 中期优化
    if recommendations['medium_term']:
        html += '<h4 style="margin: 25px 0 15px 0; color: #1e3c72; font-size: 16px;">📅 中期优化（1-3 天）</h4>'
        for rec in recommendations['medium_term']:
            html += generate_recommendation_card(rec)

    return html


def generate_recommendation_card(rec):
    """生成单个建议卡片"""
    return f'''
    <div class="recommendation-card">
        <div class="recommendation-header">
            <div class="recommendation-title">{rec['action']}</div>
        </div>
        <div class="recommendation-content">
            <strong>操作内容：</strong>{rec['content']}<br>
            <strong>操作依据：</strong>{rec['basis']}<br>
            <strong>预期效果：</strong>{rec['effect']}<br>
            <strong style="color: #d32f2f;">注意事项：</strong>{rec['notice']}
        </div>
    </div>
    '''


def generate_missing_data_section(missing_data):
    """生成数据缺口区块"""
    items_html = ''
    for item in missing_data:
        items_html += f'''
        <div class="missing-data-item">
            <div class="missing-param">{item['param']}</div>
            <div class="missing-impact">{item['impact']}</div>
        </div>
        '''

    return f'<div style="background: #f8f9fa; padding: 15px; border-radius: 10px;">{items_html}</div>'


def main():
    parser = argparse.ArgumentParser(description='生成高炉炉况诊断 HTML 报告')
    parser.add_argument('--input', '-i', default='assets/diagnosis_output_latest.json',
                        help='输入 JSON 数据文件路径')
    parser.add_argument('--output', '-o', default=None,
                        help='输出 HTML 文件路径')

    args = parser.parse_args()

    skill_dir = Path(__file__).parent.parent
    input_path = skill_dir / args.input

    if args.output:
        output_path = skill_dir / args.output
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_filename = f"高炉炉况诊断报告_{timestamp}.html"
        output_path = skill_dir / output_filename

    print(f"[读取] 数据文件: {input_path}")

    if not input_path.exists():
        print(f"[错误] 数据文件不存在: {input_path}")
        return 1

    try:
        with open(input_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        print("[成功] 数据读取成功")
        print("[分析] 进行诊断分析...")

        print(f"[生成] HTML 报告: {output_path}")
        output_file = generate_html_report(data, output_path)
        print(f"[成功] 报告已生成: {output_file}")

        # 生成最新版本
        latest_path = skill_dir / "高炉炉况诊断报告_latest.html"
        generate_html_report(data, latest_path)
        print(f"[成功] 最新报告链接已更新")

        # 启动 HTTP 服务器（如果尚未启动）
        server_port = start_http_server(skill_dir, 8180)
        if server_port:
            # 生成 HTTP URL
            latest_url = get_report_url(skill_dir, "高炉炉况诊断报告_latest.html", server_port)

            # 输出可点击的 HTTP 链接
            print("\n" + "="*60)
            print("诊断报告已生成，点击以下链接在浏览器中查看：")
            print("="*60)
            print(f"\n[查看诊断报告]({latest_url})")
            print("\n" + "="*60)
            print(f"\n服务器端口: {server_port}")
            print("提示: 如果链接无法打开，请确保浏览器可以访问 localhost")
        else:
            # 如果服务器启动失败，使用 file:// 协议作为后备
            latest_abs_path = latest_path.resolve()
            file_url = "file:///" + str(latest_abs_path).replace("\\", "/")
            print("\n" + "="*60)
            print("诊断报告已生成（HTTP服务器启动失败，使用本地文件链接）：")
            print("="*60)
            print(f"\n[查看诊断报告]({file_url})")
            print("\n" + "="*60)

        return 0

    except Exception as e:
        print(f"[错误] {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    exit(main())
